
// window.scrollTo(0,300);
// const element = document.getElementById('checkabout');
// element.addEventListener("click", myFunction);

// function myFunction() {
//   setTimeout(() => {
//     window.scrollTo(0,450);
    
//   }, 500);
// }

// typed js
var typed = new Typed('#element', {
    strings: ['Web Developer.', 'Youtuber.','Web Developer.'],
    typeSpeed: 80,
  });

